from django.apps import AppConfig


class QrngConfig(AppConfig):
    name = 'qrng'
